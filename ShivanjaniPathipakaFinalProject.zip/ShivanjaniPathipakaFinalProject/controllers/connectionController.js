const model = require('../models/connection');

function ListOfCategory(picks){
    var category_names = undefined;
    picks.forEach(pick=>{
        var category_name =  pick.category;
        if(category_names === undefined){
            category_names = [];
            category_names.push(category_name);
        }
        else if(category_names.findIndex(cat_name => cat_name === category_name) == -1)
        {
            category_names.push(category_name);
        }
    });
    return category_names;
}

exports.index = (req,res,next) => {
    model.find()
    .then(picks=>{
        let category = ListOfCategory(picks)
        res.render('./connection/index', {picks, category});
    })
    .catch(err=>next(err));
};

exports.new = (req,res) => {
    res.render('./connection/new');
};

exports.create = (req,res,next) => {
    let pick = new model(req.body);
    pick.host = req.session.user;
    pick.save()
    .then(pick=> {
        req.flash('success', 'Service Successfully Created!');
        res.redirect('/connections')
    })
    .catch(err=>{
        if(err.name === 'ValidationError') {
            err.status = 400;
            req.flash('error', err.message);
            return res.redirect('back');
        }
    });
};

exports.show = (req, res, next) => {
    let id = req.params.id;
    
    model.findById(id).populate('host', 'firstName lastName')
    .then(pick=>{
        if(pick){
            const rsvp_Yes = pick.rsvp.filter(({rsvpResponse}) => rsvpResponse == 'YES');
            return res.render('./connection/show',{pick, rsvp_Yes});
        }else{
            let err = new Error('There is no service with id ' +id+ ' ');
            err.status=404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

exports.edit = (req,res,next) => {
    let id = req.params.id;

    model.findById(id)
    .then(pick=>{
        if (pick){
            console.log(pick);
            res.render('./connection/edit', {pick});
        }
        else
        {
            let err = new Error('There is no service with id ' +id+ ' to edit');
            err.status=404;
            next(err);
    }})
    .catch(err=>next(err));
};

exports.update = (req,res,next)=> {
    let pick = req.body;
    let id = req.params.id;

    model.findByIdAndUpdate(id, pick, {useFindAndModify: false, runValidators: true})
    .then(pick=>{
        if (pick){
            req.flash('success', 'Service Successfully Updated!');
            res.redirect('/connections/'+id);
        }   
        else{
            let err = new Error('There is no service with id ' +id+ ' to update');
            err.status=404;
            next(err);
        }
    })
    .catch(err=> {
        if(err.name === 'ValidationError'){
            err.status = 400;
            req.flash('error', err.message);
            return res.redirect('back');
        }
    });
};

exports.delete = (req,res,next)=> {
    let id = req.params.id;

    model.findByIdAndDelete(id, {useFindAndModify: false}) 
    .then(pick=>{
        if(pick){
            req.flash('success', 'Service Successfully Deleted!');
            res.redirect('/connections');
        }    
        else{
            let err = new Error('There is no service with id ' +id+ ' to delete');
            err.status=404;
            next(err);
        }
    })    
    .catch(err=>next(err));
};

exports.rsvp = (req, res, next) =>{
    let id=req.params.id;
    let currentrsvp_Response =  req.query.rsvp.toUpperCase();
    let userId = req.session.user;

    model.findById(id)
    .then(pick =>{
        if(userId == pick.host){
            req.flash('error', 'RSVP is not allowed for self created service');
            let err = new Error('Unauthorized to access the resources');
            err.status = 401;
            return next(err);
        }else if(currentrsvp_Response == ''){
            req.flash('error', 'RSVP cannot be empty. Value is required!');
            return res.redirect('/');
        }else if(currentrsvp_Response != 'YES' && currentrsvp_Response != 'NO' && currentrsvp_Response != 'MAYBE'){
            req.flash('error', 'RSVP values can only be YES, NO or MAYBE!');
            return res.redirect('/');
        }else{
            const oldrsvp_Response = pick.rsvp.filter(({user}) => user == userId);
            if(oldrsvp_Response.length != 0){
                const oldrsvp_ResponseValues = oldrsvp_Response[0];
                oldrsvp_ResponseValues.rsvpResponse = currentrsvp_Response;
            }else{
                var rsvpElement = {
                    user : userId,
                    rsvpResponse : currentrsvp_Response
                };
                pick.rsvp.push(rsvpElement);
            }
            model.findByIdAndUpdate(id, pick, {useFindAndModify: false, runValidators: true})
            .then(pick=>{
                if(pick){
                    req.flash('success', 'Successfully created RSVP for this servcie!');
                    res.redirect('/users/profile');

                }   
            })
            .catch(err=>next(err));
        }
    })
    .catch(err=>next(err));
};

exports.deleteRsvp = (req, res, next) => {
    let id = req.params.id;
    model.findById(id)
    .then(pick =>{
        if(pick){
            const rsvp_Delete = pick.rsvp.filter(({user}) => user == req.session.user);
            let index = pick.rsvp.indexOf(rsvp_Delete);
            pick.rsvp.splice(index,1);

            model.findByIdAndUpdate(id, pick, {useFindAndModify:false, runValidators:true})
            .then(pick =>{
                if(pick){
                    req.flash('success', 'Successfully Deleted RSVP Service!');
                    res.redirect('/users/profile');
                }
            })
        }
    })
    .catch(err=>next(err));
}
