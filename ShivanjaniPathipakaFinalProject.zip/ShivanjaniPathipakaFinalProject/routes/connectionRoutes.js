const express = require('express');
const controller = require('../controllers/connectionController');
const {isLoggedIn, isAuthor} = require('../middlewares/auth');
const {isValidateId} = require('../middlewares/validator');
const {isValidateConnection, isValidateResult} = require('../middlewares/validator');
const router = express.Router();

router.get('/',controller.index); 

router.get('/new', isLoggedIn, controller.new); 

router.post('/', isLoggedIn, isValidateConnection, isValidateResult, controller.create);

router.get('/:id', isValidateId, controller.show);

router.get('/:id/edit', isValidateId, isLoggedIn, isAuthor, controller.edit);

router.put('/:id', isValidateId, isLoggedIn, isAuthor, isValidateConnection, isValidateResult, controller.update);

router.delete('/:id', isValidateId, isLoggedIn, isAuthor, controller.delete);

router.post('/:id', isValidateId, isLoggedIn, controller.rsvp);

router.delete('/:id/rsvp', isValidateId, isLoggedIn, controller.deleteRsvp);

module.exports = router;

