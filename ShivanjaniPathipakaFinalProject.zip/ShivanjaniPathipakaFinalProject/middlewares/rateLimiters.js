const rateLimit = require('express-rate-Limit');

exports.logInLimiter = rateLimit({
    windowMs: 60*1000, //if you continue login for 1 min
    max: 5, // in 5 chances
    //message: 'Too many Login requests'
    handler: (req,res,next)=>{
        let err = new Error('Too Many log in requests. Please re-try after sometime');
        err.status = 429;
        return next(err);
    }
})