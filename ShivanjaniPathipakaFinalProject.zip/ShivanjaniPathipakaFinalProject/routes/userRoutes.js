const express = require('express');
const controller = require('../controllers/userController');
const {isGuest, isLoggedIn} = require('../middlewares/auth');
const {logInLimiter} = require('../middlewares/rateLimiters');
const {isValidateSignUp, isValidateLogin, isValidateResult } = require('../middlewares/validator');
const router = express.Router();

router.get('/new', isGuest, controller.new);

router.post('/', isGuest, isValidateSignUp, isValidateResult, controller.create);

router.get('/login', isGuest, controller.getUserLogin);

router.post('/login', logInLimiter, isGuest, isValidateLogin, isValidateResult, controller.login);

router.get('/profile', isLoggedIn, controller.profile);

//router.post('/login', controller.loginDetails);

router.get('/logoff', isLoggedIn, controller.logoff);

module.exports = router;