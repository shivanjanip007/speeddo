const {body} = require('express-validator');
const {validationResult} = require('express-validator');
var current_Date = new Date().toJSON().slice(0,10);

exports.isValidateId = (req, res, next)=>{
    let id = req.params.id;
    //an objectId is a 24-bit Hex string
    if(id.match(/^[0-9a-fA-F]{24}$/))
        return next();
    else{
        let err = new Error('Invalid Service Id!');
        err.status = 400;
        return next(err);
    }
};

exports.isValidateSignUp = [body('firstName', 'First Name cannot be empty').notEmpty().trim().escape(),
body('lastName', 'Last name cannot be empty').notEmpty().trim().escape(),
body('email', 'Email cannot be empty and must be an active account in a valid format!').isEmail().trim().escape().normalizeEmail(),
body('password', 'Password must be of min 8 character length and max of 64 characters').isLength({min:8,max:64})];

exports.isValidateLogin = [body('email', 'Email cannot be empty and must be an active account in a valid format!').isEmail().trim().escape().normalizeEmail(),
body('password', 'Password must be of min 8 character length and max of 64 characters').isLength({min:8,max:64})];

exports.isValidateConnection = 
[body('title','Title must be 3 or more characters length').isLength({min:3}).trim().escape(),
body('details','Details must be 10 or more characters length').isLength({min:10}).trim().escape(),
body('highlights','Highlights must be 3 or more character length').isLength({min:3}).trim().escape(),
body('est_date','Date cannot be empty and should be valid date!').isDate().trim().escape(),    
body('est_date','Date Should be after Current date').trim().escape().isAfter(current_Date),
body('start_time','Start Time cannot be empty').notEmpty().trim().escape(),
body('end_time','End Time cannot be empty').notEmpty().trim().escape().custom((value, {req})=>{
    if(value < req.body.start_time){
        throw new Error('End Time Should be after Start Time!')
    }
    else return true;
}),
body('location','Location cannot be empty').notEmpty().trim().escape(),
body('image','Please provide Image URL').notEmpty().trim(),
];

exports.isValidateResult = (req,res,next) =>{
    let error = validationResult(req);
    if(!error.isEmpty()){
        error.array().forEach(err => {
            req.flash('error', err.msg);   
        });
        return res.redirect('back');
    }else{
        return next();
    }
}