//require app
const express = require('express');
const morgan = require('morgan');
const methodOverride = require('method-override');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo'); //session store
const flash = require('connect-flash'); //to store msg
const connectionRoutes = require('./routes/connectionRoutes');
const mainRoutes = require('./routes/mainRoutes');
const userRoutes = require('./routes/userRoutes');

//express app
const app = express();

//connect app
let port=8080;
let host = 'localhost';
app.set('view engine', 'ejs');

//connect to database
mongoose.connect('mongodb://localhost:27017/speeddo',
    {useNewUrlParser: true, useUnifiedTopology: true })                
.then(()=>{
    app.listen(port, host, () => {
        console.log('Server is up running in port', port);
    });
})
.catch(err=>console.log(err.message));

//middleware for session and cookies
app.use(session({
    secret: "ajfeirf90aeu9eroejfoefj", //encrypt the cookies in header
    resave: false,
    saveUninitialized: false, 
    cookie:{maxAge: 60*60*1000}, //expire in 1 hour (millisecond)
    store: new MongoStore({mongoUrl: 'mongodb://localhost:27017/speeddo'}) //if session is created, the session will be addedd to speeddo DB. By default collection name is "session". It can also be resetted in db, recommended for production mode
}));

//if session is created, flash is stored in session
app.use(flash());

app.use((req, res, next) => { 
    res.locals.user = req.session.user||null; //stored session user for header condition
    res.locals.errorMessages = req.flash('error');
    res.locals.successMessages = req.flash('success');
    res.locals.firstName = req.session.name;
    next();
});

//mount middleware
app.use(express.static('public'));
app.use(express.urlencoded({extended:true}));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));

//navigation sites
app.use('/', mainRoutes);
app.use('/connections', connectionRoutes);
app.use('/users', userRoutes)

//404 error handler
app.use((req, res, next) => {
    let err = new Error('The Server Cannot Locate' + req.url);
    err.status=404;
    next(err);
});

//500 error handler
app.use((err, req, res, next) => {
    console.log(err.stack);
    if(!err.status){
        err.status=500;
        err.message=("Internal Server Error");
    }
    res.status(err.status);
    res.render('error', {error:err});
});