const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    firstName: {type: String, required: [true, 'cannot be empty']},
    lastName: {type: String, required: [true, 'cannot be empty']},
    email: {type: String, required: [true, 'cannot be empty'], unique: [true, 'This Email address has been used']},
    password: {type: String, required: [true, 'cannot be empty']},
});

//encrypt the password before saving to DB.  
userSchema.pre('save', function(next){
    let user = this; //current details entered in sign up page
    if(!user.isModified('password'))
        return next();
    bcrypt.hash(user.password, 10)//if password modified, hash it
    .then(hash=>{
        user.password = hash; //replacing password with hash value
        next();
    })
    .catch(err=>next(err));
});

//compare the entered password with the stored hash in db 
userSchema.methods.comparePassword = function(inputPassword){
    let user = this;
    return bcrypt.compare(inputPassword, user.password);
}

module.exports = mongoose.model('User', userSchema);

