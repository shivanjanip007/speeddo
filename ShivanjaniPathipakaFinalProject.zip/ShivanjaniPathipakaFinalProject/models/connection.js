const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const connectionSchema = new Schema({
    category:{type: String, required: [true, 'Category is mandatory!']},
    title:{type: String, required: [true, 'Title is mandatory!']},
    highlights:{type: String, required: [true, 'Sub-title is mandatory!']},
    details:{type: String, required: [true, 'Details are mandatory!'], minLength: [10,'Please provide details of atleast 10 characters']}, 
    est_date:{type: String, required: [true, 'Start date is mandatory!']},
    start_time:{type: String, required: [true, 'Start time is mandatory']},
    end_time:{type: String, required: [true, 'End time is mandatory!']},
    host:  {type: Schema.Types.ObjectId, ref:'User'}, 
    location:{type: String, required: [true, 'Location is mandatory!']}, 
    image:{type: String, required: [true, 'Category is mandatory']},
    rsvp : [{user: {type:Schema.Types.ObjectId, ref:'User'}, rsvpResponse:{type: String, required:[true, 'RSVP response is required!']}}]
});

//collection name is picks in db
module.exports = mongoose.model('Pick', connectionSchema);